import { Component } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs'
import {
	FormGroup,
	FormControl,
	FormBuilder,
	Validators,
} from '@angular/forms'

@Component({
  selector: 'data-driven',
	template: `
	<form [formGroup]='myForm' (ngSubmit)='onSubmit()'>
		<input type="text" formControlName='lname'>
		<input type="text" formControlName='fname'>
		<input type="text" formControlName='email'>
		<input type="password" formControlName='pass'>
		<input type="password" formControlName='confirm'>
	</form>
	`,
})
export class FormComponent {
  title = 'datadriven';
	myForm: FormGroup;

	constructor(private formBuilder: FormBuilder, private http: HttpClient) {
		this.myForm = formBuilder.group({
			fname: ['Asaad', Validators.required],
			lname: ['Asaad', Validators.required],
			email: ['example@example.com', Validators.required, this.emailValidator],
			pass: ['test', Validators.required],
			confirm: ['test', Validators.required]
		})
	}

	emailValidator(control: FormControl): Observable<any> {
		console.log(this+'---------------------------------------')
		return this.http.post('http://home:8080/api/email', control )
	}

	onSubmit() {
		console.log(this.myForm)
	}
}

